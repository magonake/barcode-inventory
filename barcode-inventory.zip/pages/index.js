import { useState, useEffect, useRef } from 'react'
import { Html5Qrcode } from 'html5-qrcode'

export default function Home() {
  const [products, setProducts] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('barcodeList')
      return saved ? JSON.parse(saved) : []
    }
    return []
  })
  const scannerRef = useRef(null)
  const [scanning, setScanning] = useState(false)

  useEffect(() => {
    localStorage.setItem('barcodeList', JSON.stringify(products))
  }, [products])

  const handleCodeScanned = (decodedText) => {
    setProducts((prev) =>
      prev.includes(decodedText)
        ? prev.filter((code) => code !== decodedText)
        : [...prev, decodedText]
    )
  }

  const startScanner = () => {
    if (scannerRef.current) return
    setScanning(true)
    const html5QrCode = new Html5Qrcode('reader')
    scannerRef.current = html5QrCode
    html5QrCode
      .start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: 250 },
        handleCodeScanned,
        () => {}
      )
      .catch((err) => {
        console.error('Camera start error:', err)
        setScanning(false)
      })
  }

  const stopScanner = () => {
    if (scannerRef.current) {
      scannerRef.current.stop().then(() => {
        scannerRef.current.clear()
        scannerRef.current = null
        setScanning(false)
      })
    }
  }

  return (
    <div style={{ padding: '1rem', maxWidth: 500, margin: 'auto' }}>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1rem' }}>
        Lista Produktów
      </h1>
      <div style={{ marginBottom: '1rem' }}>
        {!scanning ? (
          <button onClick={startScanner}>Włącz skaner</button>
        ) : (
          <button onClick={stopScanner}>Wyłącz skaner</button>
        )}
      </div>
      <div id='reader' style={{ marginBottom: '1rem', width: '100%' }}></div>
      <ul style={{ listStyleType: 'disc', paddingLeft: '1.5rem' }}>
        {products.map((code, index) => (
          <li key={index}>{code}</li>
        ))}
      </ul>
    </div>
  )
}
